function abrirJanela(obj){
    obj.src="janelaaberta.png";
}
function fecharJanela(obj){
	obj.src="janelafechada.png";
}
function quebrarJanela(obj){
	obj.src="janelaquebra.png";
}

    
