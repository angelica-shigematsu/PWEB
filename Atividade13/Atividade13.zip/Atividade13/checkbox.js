function mudarValor(){
	var frase = document.forms.formulario.elements[0].value;
	var fraseMaiusculo = document.getElementById('maius');
	var fraseMinusculo = document.getElementById('min');
	
	if(fraseMaiusculo.checked == true && fraseMinusculo.checked ==true){
		document.getElementById('resultado').value = frase.toUpperCase() + " " + frase.toLowerCase() ;  
		return true;
	}
    else if(fraseMaiusculo.checked){
		document.getElementById('resultado').value =  frase.toUpperCase();
		return true;
    }
    else 
    {
		document.getElementById('resultado').value = frase.toLowerCase();
		return true;
	}
}

