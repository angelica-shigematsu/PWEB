function Retangulo(x,y){
    this.x = x;
    this.y = y;

    this.somar = function(){
        return this.x * this.y;
    }
}

var base = parseInt(prompt("Digite o valor da base: "));
var altura = parseInt(prompt("Digite o valor da altura: "));
var retangulo = new Retangulo(base, altura);

alert("Resultado: " + retangulo.somar());
