const fs = require('fs');
const data = fs.readFileSync('file.txt');
//quando não lê tudo não faz nada
console.log(data.toString());