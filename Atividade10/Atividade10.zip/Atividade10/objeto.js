var aluno1 = new Object();
aluno1.RA = '0030482021035';
aluno1.nome = 'Angélica';


alert(aluno1.RA);
alert(aluno1.nome);

var aluno1 =
{
    RA: '0030482021035',
    nome: 'Angélica'
}

alert(aluno1.RA);
alert(aluno1.nome);


var aluno1 = {};
aluno1.RA = '123456678';
aluno1.nome = 'Shigematsu'

alert(aluno1.RA);
alert(aluno1.nome);