var valores = new Array(3);
var maximo;
var valorCresc;
for(var i = 0; i <3; i++){
    valores[i] = parseInt(prompt("Digite " + (i+1) + "° número: "));
    console.log(valores[i]);
}

maximo = Math.max(...valores);
valorCresc = valores.sort(function(a,b){return a - b});
alert("O valor maior entre os 3 são: " +  maximo);
alert("Os valores em ordem" + valorCresc);
