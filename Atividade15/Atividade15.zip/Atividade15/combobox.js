function confirmar(){
	
	var curso = document.getElementById("curso");
	var nomeCurso = curso.options[curso.selectedIndex].text;
	resposta = confirm("Deseja escolher o curso de "+ nomeCurso + " ?");
	if(resposta === true){
		if(nomeCurso == "Análise e Desenvolvimento de Sistemas"){
			window.open("http://www.fatecsorocaba.edu.br/curso_ads.asp", "_blank", 'width="600px"', 'height="300px"');
		}else if(nomeCurso == "Eletrônica Automotiva"){
			window.open("http://www.fatecsorocaba.edu.br/curso_ea.asp", "_blank", 'width="600px"', 'height="300px"');
		}else if(nomeCurso === "Fabricação Mecânica"){
			window.open("http://www.fatecsorocaba.edu.br/curso_fm.asp", "_blank", 'width="600px"', 'height="300px"');
		}else if(nomeCurso === "Gestão Empresarial"){
			window.open("http://www.fatecsorocaba.edu.br/curso_ead-ge.asp", "_blank", 'width="600px"', 'height="300px"');
		}else if(nomeCurso === "Gestão de Qualidade"){
			window.open("http://www.fatecsorocaba.edu.br/curso_gq.asp", "_blank", 'width="600px"', 'height="300px"');
		}else if(nomeCurso === "Logística"){
			window.open("http://www.fatecsorocaba.edu.br/curso_log.asp", "_blank", 'width="600px"', 'height="300px"');
		}else if(nomeCurso === "Manufatura Avançada"){
			window.open("http://www.fatecsorocaba.edu.br/curso_ma.asp", "_blank", 'width="600px"', 'height="300px"');
		}else if(nomeCurso === "Processo Metalúrgicos"){
			window.open("http://www.fatecsorocaba.edu.br/curso_pm.asp", "_blank", 'width="600px"', 'height="300px"');
		}else if(nomeCurso === "Polímeros"){
			window.open("http://www.fatecsorocaba.edu.br/curso_pol.asp", "_blank", 'width="600px"', 'height="300px"');
		}else if(nomeCurso === "Projetos Mecânicos"){
			window.open("http://www.fatecsorocaba.edu.br/curso_proj.asp", "_blank", 'width="600px"', 'height="300px"');
		}else{
			window.open("http://www.fatecsorocaba.edu.br/curso_sb.asp", "_blank", 'width="600px"', 'height="300px"');
		}
	}
}
