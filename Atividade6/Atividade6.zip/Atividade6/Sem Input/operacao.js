var decisao = true;
do{
	if(decisao){
		var numero1 = parseInt(prompt("Digite o 1º número: "));
		var numero2 = parseInt(prompt("Digite o 2º número: "));

		var soma = numero1 + numero2;
		var subtracao = numero1 - numero2;
		var produto = numero1 * numero2;
		var divisao = numero1 / numero2;
		var resto = numero1 % numero2;
		
		alert("Soma: " + soma);
		alert("Subtração: " + subtracao);
		alert("Produto: " + produto);
		alert("Divisão: " + divisao);
		alert("Resto: " + resto);
	}else{
		break;
	}

    decisao = confirm("Clique se deseja realizar de novo");
}while(decisao);
