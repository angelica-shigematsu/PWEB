var decisao = true;
do{
    if(decisao){
    var nome = prompt("Qual seu nome: ");
    var nota1 = parseFloat(prompt("Digite sua nota 1: "));
    var nota2 = parseFloat(prompt("Digite sua nota 2: "));
    var nota3 = parseFloat(prompt("Digite sua nota 3: "));

    var media = (nota1 + nota2 + nota3)/3;
	
    alert(media);
    }
    else{
        break;
    }
    decisao = confirm("Clique se deseja realizar de novo");
}while(decisao);

