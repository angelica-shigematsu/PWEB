function operacao(){
	var numero1 = parseFloat(document.querySelector("#valor1").value);
	var numero2 = parseFloat(document.querySelector("#valor2").value);
	
	var soma = numero1 + numero2;
	var subtracao = numero1 - numero2;
	var produto = numero1 * numero2;
	var divisao = numero1 / numero2;
	var resto = numero1 % numero2;
	
	document.getElementById("resultado").innerHTML = 
	'<label> Soma </label> <input type="text" readonly value="'+ soma + '"> <br>'+
	'<label> Subtração </label> <input type="text" readonly value="'+ subtracao + '"> <br>'+
	'<label> Produto </label> <input type="text" readonly value="'+ produto + '"> <br>'+
	'<label> Divisão </label> <input type="text" readonly value="'+ divisao + '"> <br>' +
	'<label> Resto </label> <input type="text" readonly value="'+ resto + '">' ;
}