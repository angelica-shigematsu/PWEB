function media(){
	var nome = document.querySelector("#nome").value;
	var nota1 = parseFloat(document.querySelector("#valor1").value);
	var nota2 = parseFloat(document.querySelector("#valor2").value);
	var nota3 = parseFloat(document.querySelector("#valor3").value);
	
    var media = (nota1 + nota2 + nota3)/3;
    document.getElementById("resultado").innerHTML = 
	'<label>Resultado da Média:</label>' +
	'<input type="number" readonly value="' + media + '">';
    
}