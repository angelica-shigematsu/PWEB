var escolha = prompt("Escolha papel, pedra ou tesoura");
var computador = "";
var resultado = "";
var max = Math.floor(3);
var min = Math.ceil(1);
var randomNum = Math.floor((Math.random() * (max - min)) + min);

if(randomNum === 1){
     computador = "papel";
}
else if(randomNum === 2){
    computador = "pedra";
}
else{
    computador = "tesoura";
}

if(computador === escolha){
    resultado = "Empate";
}
else if (escolha === "pedra" && computador === "tesoura"){
    resultado = "Pedra quebra tesoura";
}
else if (escolha === "tesoura" && computador === "papel"){
    resultado = "Tesoura quebra papel";
}
else if (escolha === "papel" && escolha === "pedra"){
    resultado = "Papel quebra pedra";
}
else{
    resultado = "Você perdeu";
}
alert("Computador: "+ computador)
alert(resultado);