var idade = [];
var sexo = [];
var opiniao = [];
var mediaIdade;
var opiniaoPessima = 0;
var opiniaoOtima= 0;
var qtdeTotal = 3;
var qtdePessoas = 0;
let qtdeOpiniao =  0 


for(var i = 0; i < qtdeTotal; i++){
    idade[i] = parseInt(prompt("Digite sua idade: "));
    sexo[i] = prompt("Digite seu sexo (f) feminino ou (m) masculino: ").toLowerCase();
    opiniao[i] = prompt("Digite sua opinião (p)pessimo (o)ótimo (b)bom: ").toLowerCase();
}
//Média das idades que responderam
function media(idade){
    let mediaIdade = 0;
    for(var j = 0; j < qtdeTotal; j++){
        mediaIdade += idade[j];
    }
    return (mediaIdade/qtdeTotal).toFixed(2);
}

//Idade da pessoa mais velha
function idadeVelha(idade){
    let maisVelha = idade[0];
    for(var z = 1; z < 45; z++){
        if(idade[z]> maisVelha)
            maisVelha = idade[z];
    }
    return maisVelha;
}
//Idade da pessoa mais nova
function idadeNova(idade){
    let maisNova = idade[0];
    for(var x = 1; x < 45; x++){
        if(idade[x] < maisNova)
            maisNova = idade[x];
    }
    return maisNova;
}
//Opinião de pessoas com opinião péssima
function respostaPessima(opiniao){
    let opiniaoPessima = 0;
    for(var qtde = 0; qtde < qtdeTotal; qtde++){
        if(opiniao[qtde]=="p")
            opiniaoPessima += 1;
    }
    return opiniaoPessima;
} 
  
// função que devolve a porcentagem de pessoas com opinião bom
	for(var op = 0; op < qtdeTotal; op++){
        if(opiniao[op] === "o")
            qtdeOpiniao += 1;
}                                                               
    alert("Porcentagem de pessoas com opinião bom: " + (qtdeOpiniao*100)/qtdeTotal);
	qtdeOpiniao = 0;
  
  
// função que devolve a porcentagem de pessoas com opinião bom
	for(var op = 0; op < qtdeTotal; op++){
        if(opiniao[op] === "b")
            qtdeOpiniao += 1;
}                                                               
    alert("Porcentagem de pessoas com opinião bom: " + (qtdeOpiniao*100)/qtdeTotal);
	
//números de homens que responderam
	for(var i = 0; i < qtdeTotal; i++){
        if(sexo[i]=== "f"){
            qtdePessoas += 1;
        }
    }
		alert("O número de mulheres que responderam o questionário: " + qtdePessoas);
		qtdePessoas = 0;

//números de mulheres 
    for(var i = 0; i < qtdeTotal; i++){
        if(sexo[i]=== "m"){
            qtdePessoas += 1;
        }
    }
	 alert("O número de homens que responderam o questionário: " + qtdePessoas);



alert("Média de pessoas que responderam: " + media(idade));
alert("Idade da pessoa mais velha: " + idadeVelha(idade));
alert("Idade da pessoa mais nova: " + idadeNova(idade));
alert("Quantidade de pessoas de opinião péssima: "+ respostaPessima(opiniao));





