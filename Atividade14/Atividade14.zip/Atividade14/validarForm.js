function validarDados(){

    if(document.forms.formulario.elements[0].value == "" || document.forms.formulario.elements[0].value.length < 10)
    {
        alert("Preencha corretamente o nome");
        document.forms.formulario.elements[0].focus();
        return false;
    };

    if(document.forms.formulario.elements["email"].value == "" || 
    document.forms.formulario.elements["email"].value.indexOf('@') == -1
    || document.forms.formulario.elements['email'].value.indexOf('.') == -1){
        alert("Prencha corretamente o e-mail");
        return false;
    };

    if(document.forms.formulario.elements.mensagem.value == "" || 
    document.forms.formulario.elements.mensagem.value.length < 20){
        alert("Preencha corretamente o comentário");
        return false;
    }

	var resposta = document.querySelector("input[name=resposta]:checked").value;
	if(resposta === "sim"){
		 alert("Que bom que você voltou a visitar está página!");
	}else{
		alert("Volte sempre à está página!");
	}
    
}